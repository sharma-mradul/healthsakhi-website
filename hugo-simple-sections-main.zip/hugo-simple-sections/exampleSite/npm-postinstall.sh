cd themes/hugo-simple-sections && npm install
